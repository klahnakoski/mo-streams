# More Streams

Can code be more elegant with method chaining?

